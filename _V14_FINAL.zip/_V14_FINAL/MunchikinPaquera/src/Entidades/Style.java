package Entidades;

import java.io.Serializable;

/*
    Uma lista com estilos de paquerador 
    Estilos dão bônus nos encontros dependendo da dama que é paquerada

 */
public enum Style implements Serializable {
    ROMÂNTICO, BADBOY, ENGRAÇADO, NERD, GALÃ;
}
